$(document).ready(function() {
 
  $("#owl-main").owlCarousel({
      slideSpeed : 300,
      paginationSpeed : 400,
      singleItem:true,
      autoPlay: 5000,
      transitionStyle : "fade"
      // "singleItem:true" is a shortcut for:
      // items : 1, 
      // itemsDesktop : false,
      // itemsDesktopSmall : false,
      // itemsTablet: false,
      // itemsMobile : false
  });
 
});


$(document).ready(function() {
 
  var owl = $("#owl-hot");
 
  owl.owlCarousel({
    slideSpeed : 300,
    paginationSpeed : 400,
    autoPlay: 3000,
    stopOnHover: true,
    pagination: false
  });
 
  // Custom Navigation Events
  $(".owl-hot-next").click(function(){
    owl.trigger('owl.next');
  })
  $(".owl-hot-prev").click(function(){
    owl.trigger('owl.prev');
  })
});

$(document).ready(function() {
 
  var owl = $("#owl-new");
 
  owl.owlCarousel({
    slideSpeed : 300,
    paginationSpeed : 400,
    autoPlay: 3000,
    stopOnHover: true,
    pagination: false
  });
 
  // Custom Navigation Events
  $(".owl-new-next").click(function(){
    owl.trigger('owl.next');
  })
  $(".owl-new-prev").click(function(){
    owl.trigger('owl.prev');
  })
});