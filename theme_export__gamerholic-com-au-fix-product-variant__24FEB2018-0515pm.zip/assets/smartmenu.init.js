$(document).ready(function(){
$(function() {
  $('#main-menu').smartmenus({
    mainMenuSubOffsetX: -1,
    subMenusSubOffsetX: 10,
    subMenusSubOffsetY: 0
  });
});

// SmartMenus mobile menu toggle button
$(function() {
  var $mainMenuState = $('#main-menu-state');
  if ($mainMenuState.length) {
    // animate mobile menu
    $mainMenuState.change(function(e) {
      var $menu = $('#main-menu');
      if (this.checked) {
        $menu.hide().slideDown(250, function() { $menu.css('display', ''); });
      } else {
        $menu.show().slideUp(250, function() { $menu.css('display', ''); });
      }
    });
    // hide mobile menu beforeunload
    $(window).bind('beforeunload unload', function() {
      if ($mainMenuState[0].checked) {
        $mainMenuState[0].click();
      }
    });
  }
});

    
  $(function() {

    var $anchor = $("#scroller-anchor");
    var $scroller = $('#scroller');
    var $gap = $('#scroller-gap');

    var move = function() {
        var st = $(window).scrollTop();
        var ot = $anchor.offset().top;
        if(st > ot) {
            $scroller.css({
                position: "fixed",
                top: "0px",
                width: "100%",
                padding: "0px 0px 0px 0px",
            });
          $gap.css({
            height: "48px"
          })
        } else {
            if(st <= ot) {
                $scroller.css({
                    position: "relative",
                    top: "",
                  padding: ""
                });
               $gap.css({
                height: "0px"
              })
            }
        }
    };
    $(window).scroll(move);
    move();

  });
});